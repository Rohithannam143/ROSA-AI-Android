@echo off
setlocal
set VERSION=8.9
set ROOT=%~dp0
set GHOME=%USERPROFILE%\.gradle\rosa-bootstrap\gradle-%VERSION%
if not exist "%GHOME%\bin\gradle.bat" (
  if not exist "%USERPROFILE%\.gradle\rosa-bootstrap" mkdir "%USERPROFILE%\.gradle\rosa-bootstrap"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%USERPROFILE%\.gradle\rosa-bootstrap\gradle-%VERSION%-bin.zip'; Expand-Archive -Force '%USERPROFILE%\.gradle\rosa-bootstrap\gradle-%VERSION%-bin.zip' '%USERPROFILE%\.gradle\rosa-bootstrap'"
)
call "%GHOME%\bin\gradle.bat" -p "%ROOT%" %*
