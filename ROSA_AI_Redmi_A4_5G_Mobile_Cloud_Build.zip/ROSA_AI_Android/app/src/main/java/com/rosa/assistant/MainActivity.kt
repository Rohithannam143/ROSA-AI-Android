package com.rosa.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private lateinit var transcript: TextView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("rosa", MODE_PRIVATE) }
    private val history = JSONArray()
    private val purple = Color.rgb(139, 124, 255)
    private val white = Color.WHITE
    private val muted = Color.rgb(165, 169, 190)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        requestNeededPermissions()
        if (intent?.getBooleanExtra("wake_triggered", false) == true) startListening()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 30, 22, 18)
            setBackgroundColor(Color.rgb(9, 11, 20))
        }
        val header = TextView(this).apply {
            text = "ROSA  /  PERSONAL AI"
            textSize = 13f; letterSpacing = .16f; setTextColor(purple)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(header)
        val title = TextView(this).apply {
            text = "Hello. I'm ROSA."
            textSize = 29f; setTextColor(white); setPadding(0, 16, 0, 3)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        root.addView(title)
        status = TextView(this).apply {
            text = "Your assistant is ready • Hybrid mode"
            textSize = 13f; setTextColor(muted); setPadding(0, 0, 0, 12)
        }
        root.addView(status)
        val orb = TextView(this).apply {
            text = "✦"
            textSize = 58f; gravity = Gravity.CENTER; setTextColor(white)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(92, 77, 210), Color.rgb(35, 128, 178))).apply {
                shape = GradientDrawable.OVAL
                setStroke(2, Color.rgb(172, 162, 255))
            }
        }
        val orbWrap = FrameLayout(this).apply {
            addView(orb, FrameLayout.LayoutParams(132,132,Gravity.CENTER))
        }
        root.addView(orbWrap, LinearLayout.LayoutParams(-1, 150))
        val mic = button("TAP TO TALK  🎙", true) { startListening() }
        root.addView(mic, matchWrap(54).apply { bottomMargin = 12 })
        val wake = button("Enable / disable “Hey ROSA” wake mode", false) {
            if (hasAudioPermission()) {
                val i = Intent(this, WakeWordService::class.java)
                if (WakeWordService.running) stopService(i)
                else ContextCompat.startForegroundService(this, i)
                status.text = if (WakeWordService.running) "Wake mode requested" else "Wake mode stopped"
            } else requestNeededPermissions()
        }
        root.addView(wake, matchWrap(48).apply { bottomMargin = 14 })
        val chatLabel = TextView(this).apply {
            text = "CONVERSATION"; textSize = 11f; letterSpacing = .12f
            setTextColor(muted); setPadding(2, 8, 0, 6)
        }
        root.addView(chatLabel)
        transcript = TextView(this).apply {
            text = "ROSA: Ask me anything. Try “Open YouTube” or “Set a timer for 5 minutes”."
            textSize = 14f; setTextColor(white); setPadding(14,14,14,14)
            background = rounded(Color.rgb(21,24,39), 18)
        }
        val scroll = ScrollView(this).apply { addView(transcript) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        input = EditText(this).apply {
            hint = "Message ROSA…"; setHintTextColor(muted); setTextColor(white)
            textSize = 15f; singleLine = true; setPadding(14, 12, 14, 12)
            background = rounded(Color.rgb(24,27,43), 16)
        }
        root.addView(input, matchWrap(52).apply { topMargin = 12; bottomMargin = 8 })
        root.addView(button("SEND", true) { val q = input.text.toString().trim(); if(q.isNotEmpty()){ input.setText(""); ask(q) } }, matchWrap(48))
        val settings = TextView(this).apply {
            text = "SETTINGS  •  Add Gemini API key  •  Language: Auto"
            textSize = 12f; setTextColor(muted); gravity = Gravity.CENTER
            setPadding(0, 14, 0, 0)
            setOnClickListener { showSettings() }
        }
        root.addView(settings)
        setContentView(root)
    }

    private fun button(label: String, primary: Boolean, action: () -> Unit): Button =
        Button(this).apply {
            text = label; textSize = 13f; isAllCaps = false
            setTextColor(white)
            background = rounded(if(primary) Color.rgb(91,78,205) else Color.rgb(31,35,55), 16)
            setOnClickListener { action() }
        }

    private fun matchWrap(h: Int) = LinearLayout.LayoutParams(-1, h)
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
    }

    private fun hasAudioPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun requestNeededPermissions() {
        val needed = mutableListOf<String>()
        if (!hasAudioPermission()) needed.add(Manifest.permission.RECORD_AUDIO)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (needed.isNotEmpty()) ActivityCompat.requestPermissions(this, needed.toTypedArray(), 41)
    }

    private fun startListening() {
        if (!hasAudioPermission()) { requestNeededPermissions(); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition service unavailable on this device"; return
        }
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening… speak now" }
                override fun onBeginningOfSpeech() { status.text = "I'm listening" }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "Thinking…" }
                override fun onError(error: Int) { status.text = "Didn't catch that. Tap to try again." }
                override fun onResults(results: Bundle?) {
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!words.isNullOrEmpty()) ask(words[0])
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "te-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer?.startListening(i)
        } catch (_: Exception) { status.text = "Could not start microphone" }
    }

    private fun ask(text: String) {
        append("YOU", text); status.text = "Thinking…"
        val local = localAction(text)
        if (local != null) {
            append("ROSA", local.first)
            speak(local.first)
            local.second?.let { startActivity(it) }
            status.text = "Ready"
            return
        }
        executor.execute {
            val answer = GeminiClient.reply(this, text, history, prefs.getString("api_key", "") ?: "")
            runOnUiThread {
                append("ROSA", answer); speak(answer); status.text = "Ready"
            }
        }
    }

    private fun localAction(text: String): Pair<String, Intent?>? {
        val q = text.lowercase(Locale.ROOT)
        if (q.contains("open youtube")) return Pair("Opening YouTube.", Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com")))
        if (q.contains("open chrome")) return Pair("Opening Chrome.", Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com")))
        if (q.contains("open settings")) return Pair("Opening Android settings.", Intent(android.provider.Settings.ACTION_SETTINGS))
        if (q.contains("open camera")) return Pair("Opening camera.", Intent("android.media.action.IMAGE_CAPTURE"))
        if (q.contains("open whatsapp")) return Pair("Opening WhatsApp if installed.", packageManager.getLaunchIntentForPackage("com.whatsapp"))
        if (q.contains("what time") || q.contains("current time") || q.contains("time now"))
            return Pair("It is ${java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date())}.", null)
        if (q.startsWith("set a timer") || q.startsWith("timer")) {
            val minutes = Regex("(\\d+)").find(q)?.groupValues?.get(1)?.toIntOrNull() ?: 5
            val i = Intent(android.provider.AlarmClock.ACTION_SET_TIMER).putExtra(android.provider.AlarmClock.EXTRA_LENGTH, minutes * 60).putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "ROSA timer").putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, false)
            return Pair("Setting a $minutes minute timer.", i)
        }
        if (q.contains("set an alarm") || q.contains("wake me")) {
            return Pair("Opening the clock app to set your alarm.", Intent(android.provider.AlarmClock.ACTION_SET_ALARM))
        }
        return null
    }

    private fun append(who: String, message: String) {
        transcript.append("\n\n$who: $message")
        history.put(JSONObject().put("role", if(who=="YOU") "user" else "model").put("text", message))
        while (history.length() > 12) history.remove(0)
    }

    private fun speak(text: String) { if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rosa_reply") }

    private fun showSettings() {
        val field = EditText(this).apply {
            hint = "Paste Gemini API key"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("api_key", ""))
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30,10,30,0); addView(field) }
        android.app.AlertDialog.Builder(this).setTitle("ROSA AI settings")
            .setMessage("Add your own Gemini API key to enable online AI. Without a key, ROSA uses offline commands and fallback responses.")
            .setView(box).setPositiveButton("Save") { _, _ -> prefs.edit().putString("api_key", field.text.toString().trim()).apply(); Toast.makeText(this,"API key saved on this device",Toast.LENGTH_SHORT).show() }
            .setNeutralButton("Clear key") { _, _ -> prefs.edit().remove("api_key").apply() }
            .setNegativeButton("Cancel", null).show()
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale.getDefault()
            tts.setSpeechRate(1.0f)
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        executor.shutdown()
        super.onDestroy()
    }
}
