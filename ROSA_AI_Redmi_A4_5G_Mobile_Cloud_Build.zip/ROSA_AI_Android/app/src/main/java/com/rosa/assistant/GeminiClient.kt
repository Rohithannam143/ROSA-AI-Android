package com.rosa.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {
    fun reply(context: Context, prompt: String, history: JSONArray, apiKey: String): String {
        if (apiKey.isBlank()) return offlineFallback(prompt)
        var connection: HttpURLConnection? = null
        return try {
            val model = "gemini-2.5-flash"
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 15000; readTimeout = 25000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
            val contents = JSONArray()
            val start = maxOf(0, history.length() - 8)
            for (i in start until maxOf(start, history.length() - 1)) {
                val item = history.getJSONObject(i)
                contents.put(JSONObject()
                    .put("role", if(item.optString("role") == "model") "model" else "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", item.optString("text")))))
            }
            contents.put(JSONObject().put("role","user").put("parts",JSONArray().put(JSONObject().put("text",prompt))))
            val body = JSONObject().put("system_instruction",
                JSONObject().put("parts",JSONArray().put(JSONObject().put("text",
                    "You are ROSA, a helpful Android personal assistant. Reply concisely and naturally. Support Telugu, English and Hindi; respond in the language the user uses. Never claim to have performed phone actions unless the Android app explicitly performed them."))))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("temperature",0.7).put("maxOutputTokens",700))
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if(code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if(code !in 200..299) "Online AI error ($code). Check your API key or internet connection."
            else {
                val obj = JSONObject(response)
                obj.getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            }
        } catch (_: Exception) {
            offlineFallback(prompt) + " (Offline fallback: check internet and API key for online answers.)"
        } finally { connection?.disconnect() }
    }

    private fun offlineFallback(prompt: String): String {
        val q = prompt.lowercase()
        return when {
            q.contains("hello") || q.contains("hi") -> "Hello! I'm ROSA. Add a Gemini API key in Settings for intelligent online conversations."
            q.contains("who are you") -> "I'm ROSA, your personal Android assistant. I can speak, listen, open supported apps and help with timers."
            q.contains("telugu") -> "నేను ROSA. మీకు ఎలా సహాయం చేయగలను?"
            else -> "I can handle basic phone commands offline. For full AI conversations, add your Gemini API key in ROSA Settings and connect to the internet."
        }
    }
}
