# ROSA AI — Android Assistant

A Kotlin Android Studio starter project for Redmi A4 5G (Android 16 compatible target) with:
- Hybrid design: Gemini online chat + local command/fallback handling
- Voice input through Android SpeechRecognizer
- Spoken replies through Android TextToSpeech
- English/Telugu/Hindi support via Android speech services and language-matched prompts
- Local actions: open YouTube, Chrome/web, Settings, Camera, WhatsApp; set timers and alarms
- Home-screen ROSA quick-launch widget
- Optional experimental "Hey ROSA" foreground microphone listener
- API key stored in app-private SharedPreferences (not embedded in source)

## Build
1. Open this folder in Android Studio (Ladybug or newer).
2. Allow Gradle sync; JDK 17 is recommended.
3. Install Android SDK Platform 35 and Build Tools through SDK Manager.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install `app/build/outputs/apk/debug/app-debug.apk` on the Redmi A4 5G.

## First run
1. Grant Microphone permission. Grant Notifications if prompted.
2. Open Settings in ROSA and paste your Gemini API key. The app does not include a key.
3. Connect to the internet for online AI. Without a key/network, supported local commands and a basic fallback still work.
4. Tap **TAP TO TALK** and speak. Speech recognition language availability depends on the installed Android speech provider.

## Important Android limitations
- Android does not provide unrestricted always-on microphone access. Wake mode is an experimental foreground microphone service and requires a visible user action, notification, microphone permission, and OEM background permission. Android 16 / Xiaomi battery management may stop or throttle it.
- For dependable activation use the app's microphone button or add a launcher shortcut/widget. This source project does not claim Siri-level always-on reliability.
- The system speech recognizer may use Google's/another provider's online service. It is not guaranteed offline.
- Phone actions are limited to public Android intents. ROSA cannot silently control arbitrary apps, read private messages, or change protected system settings.
- Gemini requests send conversation text to Google's API. Review its privacy terms before using sensitive data. Keep your API key private; do not commit it to Git.

## Device notes
Designed for a modern Android phone with API 26+; compile/target SDK 35. Test on the Redmi A4 5G Android 16 build. Xiaomi's permission and battery UI labels may vary.

## Add the home-screen widget
Long-press an empty area on the Android home screen → Widgets → ROSA AI → drag the widget onto the home screen. Tap it to open ROSA, then tap the microphone button.

## Build the APK using only your Android phone (GitHub Actions)

The included `.github/workflows/android-build.yml` builds the APK in GitHub's cloud runner. Your Redmi does not compile the app.

1. Download and extract this ZIP using ZArchiver.
2. In Chrome, create a new GitHub repository named `ROSA-AI-Android`.
3. Open the repository's **Add file → Upload files** page. Upload the extracted project contents, including the hidden `.github` folder and its workflow file. If needed, enable **Desktop site** in Chrome to expose the full upload interface.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab and enable workflows if GitHub asks.
6. Open **Build ROSA AI APK** and wait for the run to finish successfully.
7. Open the completed run, scroll to **Artifacts**, and download `ROSA-AI-debug-APK`.
8. Extract that artifact ZIP and tap `app-debug.apk`. If Android asks, allow your browser or file manager to install unknown apps, then install ROSA.

If the build fails, open the failed workflow run and share the first red error section.

**Security:** Never put your Gemini API key in source files or GitHub. Enter it inside ROSA Settings after installation.
